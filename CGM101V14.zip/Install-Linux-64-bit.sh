clear
echo "Welcome to the Syscomp Installer"
echo ""
echo "Copying 64-bit binary into the source code file..."
cp ./bin/linux_x86_64/CGM101-linux-x86-64 .
echo "Done"
echo ""
echo "Execute ./CGM101-linux-x86-64 to start the software."
