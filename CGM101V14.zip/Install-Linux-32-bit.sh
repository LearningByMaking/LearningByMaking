clear
echo "Welcome to the Syscomp Installer"
echo ""
echo "Copying 32-bit binary into the source code file..."
cp ./bin/linux_ix86/CGM101-linux-x86 .
echo "Done"
echo ""
echo "Execute ./CGM101-linux-x86 to start the software."
